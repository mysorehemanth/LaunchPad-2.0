            =========================
            Read Me File for MQBS2ALL
            =========================

Created : 26/08/2009   [UD]     MQBS2ALL V1.10
Update  : 20/10/2010   [TV]     MQBS2ALL V1.11
Update  : 18/01/2011   [FR]     MQBS2ALL V2.03


========
Contents
========

1. General Information 
2. Manual Corrections and Updates
3. Software Corrections and Updates
4. Known Problems


======================
1. General Information 
======================

USB driver for Starterkits and Virtual COM Port for V850, 78K and RL78.


=================================
2. Manual Corrections and Updates
=================================

None.


===================================
3. Software Corrections and Updates
===================================

3.1 Update for WindowsXP, Windows Vista and Windows 7, 32bit OS

3.2 Added driver for WindowsXP, Windows Vista and Windows 7, 64bit OS


    *.sys : Code of a part of USB driver
    *.inf : Driver and installation description
    *.cat : Added in order to avoid "This driver may crash PC" message on Windows Vista / Windows 7


=================
4. Known Problems
=================

4.1 None.


In case of any question please do not hesitate to contact:

        Technical Product Support

        Renesas Electronics Europe GmbH
        Arcadiastrasse 10
        D-40472 Duesseldorf, Germany

        email: software_support-eu@lm.renesas.com
        FAX:   ++49 - (0)211 / 65 03 - 12 79

================================
End of Read Me File for MQBS2ALL
================================